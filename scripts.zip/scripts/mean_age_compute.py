import dask.dataframe as dd

# Set the number of partitions
athlete_events_dask = dd.from_pandas(athlete_events, npartitions=4)

# Calculate the mean Age per Year ## data aggregate then compute
print(athlete_events_dask.groupby('Year').Age.mean().compute())
